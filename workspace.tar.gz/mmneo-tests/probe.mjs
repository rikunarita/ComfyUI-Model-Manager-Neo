import fs from 'node:fs'
import { pathToFileURL } from 'node:url'
const B = '"$ARENA_WORKSPACE"/ComfyUI-Model-Manager-Neo/web/manager.js'
console.log('existsSync:', fs.existsSync(B))
console.log('statSync isFile:', fs.statSync(B).isFile(), 'size:', fs.statSync(B).size)
console.log('fileURL:', pathToFileURL(B).href)
try {
  const mod = await import(pathToFileURL(B).href)
  console.log('import OK, keys:', Object.keys(mod))
} catch (e) {
  console.log('import ERR:', e.code, e.message.split('\n')[0])
}
