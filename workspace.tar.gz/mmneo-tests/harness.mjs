/**
 * Frontend runtime smoke test.
 *
 * Boots the production bundle (web/manager.js) inside jsdom with a mocked
 * window.comfyAPI, mounts the Vue app, opens the Model Manager dialog and
 * asserts that the (rewritten) dialog stack + model grid actually render
 * without runtime errors.
 */
import { JSDOM } from 'jsdom'

// The production bundle is copied next to this harness (build step) because
// the sandbox ESM loader cannot resolve cross-directory file URLs in file
// mode. `manager.js` is fully self-contained, so the copy behaves identically.
const BUNDLE_URL = new URL('./manager.js', import.meta.url).href

const errors = []
const vueWarns = []

// ---------------------------------------------------------------- jsdom ----
const dom = new JSDOM('<!doctype html><html><body></body></html>', {
  url: 'http://localhost/',
  pretendToBeVisual: true,
  runScripts: 'outside-only',
})
const { window } = dom

// expose as globals
globalThis.window = window
globalThis.document = window.document
globalThis.navigator = window.navigator
globalThis.HTMLElement = window.HTMLElement
globalThis.Element = window.Element
globalThis.Node = window.Node
// Vue's runtime-dom references these DOM constructors as bare globals
for (const g of [
  'SVGElement',
  'MathMLElement',
  'DocumentFragment',
  'Text',
  'Comment',
  'ShadowRoot',
  'Document',
  'HTMLTemplateElement',
  'NodeList',
  'HTMLCollection',
  'DOMParser',
  'MutationObserver',
  'CSS',
  'SVGGraphicsElement',
  'HTMLInputElement',
  'HTMLTextAreaElement',
  'HTMLButtonElement',
  'MouseEvent',
  'PointerEvent',
  'KeyboardEvent',
  'DragEvent',
  'FocusEvent',
  'InputEvent',
  'FileReader',
  'Blob',
  'File',
  'FileList',
  'FormData',
  'DOMRect',
  'NodeFilter',
  'NodeIterator',
  'TreeWalker',
  'Range',
  'XMLSerializer',
]) {
  if (window[g] !== undefined) globalThis[g] = window[g]
}
globalThis.Event = window.Event
globalThis.CustomEvent = window.CustomEvent
globalThis.getComputedStyle = window.getComputedStyle.bind(window)
globalThis.requestAnimationFrame = cb => setTimeout(() => cb(Date.now()), 0)
globalThis.cancelAnimationFrame = id => clearTimeout(id)
window.requestAnimationFrame = globalThis.requestAnimationFrame
window.cancelAnimationFrame = globalThis.cancelAnimationFrame

// Polyfills jsdom lacks. The ResizeObserver reports a fixed non-zero size so
// layout-dependent code (virtual list cols, card grids) exercises its real
// render path instead of degenerating to width 0.
class ResizeObserverStub {
  constructor(cb) {
    this.cb = cb
  }
  observe(el) {
    const rect = { width: 1000, height: 700, top: 0, left: 0, right: 1000, bottom: 700, x: 0, y: 0 }
    const entry = {
      target: el,
      contentRect: rect,
      borderBoxSize: [{ inlineSize: 1000, blockSize: 700 }],
      contentBoxSize: [{ inlineSize: 1000, blockSize: 700 }],
      devicePixelContentBoxSize: [{ inlineSize: 1000, blockSize: 700 }],
    }
    try {
      this.cb([entry], this)
    } catch (e) {
      errors.push('ResizeObserver cb: ' + (e.stack || e))
    }
  }
  unobserve() {}
  disconnect() {}
}
window.ResizeObserver = ResizeObserverStub
globalThis.ResizeObserver = ResizeObserverStub
class IntersectionObserverStub {
  observe() {}
  unobserve() {}
  disconnect() {}
  takeRecords() {
    return []
  }
}
window.IntersectionObserver = IntersectionObserverStub
globalThis.IntersectionObserver = IntersectionObserverStub
window.matchMedia =
  window.matchMedia ||
  (q => ({ matches: false, media: q, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} }))
globalThis.matchMedia = window.matchMedia
// Keep Node's global URL (the ESM loader relies on it); only polyfill the
// object-URL helpers jsdom lacks.
for (const U of [window.URL, globalThis.URL]) {
  if (U && !U.createObjectURL) {
    U.createObjectURL = () => 'blob:mock'
    U.revokeObjectURL = () => {}
  }
}
// jsdom provides these on window; expose them globally for the bundle
globalThis.MutationObserver = window.MutationObserver
globalThis.DOMParser = window.DOMParser
globalThis.CSS = window.CSS

// capture page errors
window.addEventListener('error', e => errors.push('window.error: ' + (e.error?.stack || e.message)))
window.addEventListener('unhandledrejection', e => errors.push('unhandledrejection: ' + (e.reason?.stack || e.reason)))

// --------------------------------------------------- mock window.comfyAPI --
const listeners = new Map()
let registeredExtension = null

function fakeResponse(payload, ok = true, status = 200) {
  return {
    ok,
    status,
    statusText: ok ? 'OK' : 'Error',
    headers: { get: () => 'application/json' },
    json: async () => payload,
    text: async () => JSON.stringify(payload),
    blob: async () => ({ type: 'application/json' }),
  }
}

const MODELS = {
  checkpoints: [
    {
      type: 'checkpoints',
      basename: 'sd_xl_base',
      extension: '.safetensors',
      subFolder: '',
      pathIndex: 0,
      sizeBytes: 6938078084,
      isFolder: false,
      preview: '/model-manager/preview/checkpoints/0/sd_xl_base.png',
      description: '',
      metadata: {},
      createdAt: 1700000000000,
      updatedAt: 1700000000000,
    },
    {
      type: 'checkpoints',
      basename: 'dreamshaper',
      extension: '.ckpt',
      subFolder: '',
      pathIndex: 0,
      sizeBytes: 2147483648,
      isFolder: false,
      preview: '/model-manager/preview/checkpoints/0/dreamshaper.png',
      description: '',
      metadata: {},
      createdAt: 1700000001000,
      updatedAt: 1700000002000,
    },
  ],
  loras: [],
}

async function fetchApi(url, options = {}) {
  const method = (options.method || 'GET').toUpperCase()
  // strip leading /model-manager
  const path = url.replace(/^\/model-manager/, '')
  if (path === '/models') return fakeResponse({ success: true, data: { checkpoints: ['/models/checkpoints'], loras: ['/models/loras'] } })
  const mFolder = path.match(/^\/models\/([^/]+)$/)
  if (mFolder) return fakeResponse({ success: true, data: MODELS[mFolder[1]] ?? [] })
  if (path === '/download/task') return fakeResponse({ success: true, data: [] })
  if (path === '/download/init') return fakeResponse({ success: true, data: {} })
  if (path.startsWith('/model-info')) return fakeResponse({ success: true, data: [] })
  if (path === '/supported-extensions') return fakeResponse({ success: true, data: ['.safetensors', '.ckpt'] })
  if (method === 'GET' && path.startsWith('/model/')) return fakeResponse({ success: true, data: { metadata: {}, description: '' } })
  return fakeResponse({ success: true, data: null })
}

const settingsStore = {}
const app = {
  registerExtension(ext) {
    registeredExtension = ext
  },
  ui: {
    settings: {
      getSettingValue: (id, def) => (id in settingsStore ? settingsStore[id] : def),
      setSettingValue: (id, val) => {
        settingsStore[id] = val
      },
      addSetting: () => {},
    },
    menuContainer: null,
  },
  menu: null,
  canvas: { selected_nodes: {}, canvas_mouse: [0, 0], selectNode() {}, copyToClipboard() {} },
  graph: { add() {}, getNodeOnPos: () => null },
  handleFile() {},
  clientPosToCanvasPos: p => p,
}

const api = {
  fetchApi,
  addEventListener(ev, cb) {
    if (!listeners.has(ev)) listeners.set(ev, new Set())
    listeners.get(ev).add(cb)
  },
  removeEventListener(ev, cb) {
    listeners.get(ev)?.delete(cb)
  },
  getSystemStats: async () => ({ system: { os: 'Linux', comfyui_version: '0.3.0' }, devices: [] }),
}

function $el(tag, propsOrChildren, children) {
  const [t, ...classes] = tag.split('.')
  const el = document.createElement(t || 'div')
  if (classes.length) el.className = classes.join(' ')
  const addChild = c => {
    if (c == null) return
    if (typeof c === 'string') el.appendChild(document.createTextNode(c))
    else el.appendChild(c)
  }
  if (Array.isArray(propsOrChildren)) propsOrChildren.forEach(addChild)
  else if (propsOrChildren instanceof window.Element) addChild(propsOrChildren)
  else if (propsOrChildren && typeof propsOrChildren === 'object') {
    for (const [k, v] of Object.entries(propsOrChildren)) {
      if (k === 'textContent') el.textContent = v
      else if (k.startsWith('on')) el.addEventListener(k.slice(2).toLowerCase(), v)
      else el.setAttribute(k, v)
    }
    if (Array.isArray(children)) children.forEach(addChild)
    else addChild(children)
  }
  return el
}

class ComfyButton {
  constructor(props = {}) {
    this.element = $el('button', { textContent: props.content || '' })
  }
}

window.comfyAPI = {
  app: { app },
  api: { api },
  ui: { $el },
  button: { ComfyButton },
}
window.LiteGraph = { createNode: () => ({ widgets: [], pos: [0, 0] }) }

// intercept console.error / Vue warn
const origError = console.error
console.error = (...args) => {
  const s = args.map(a => (a && a.stack) || String(a)).join(' ')
  if (/Vue warn|Invalid|TypeError|ReferenceError|Cannot read|is not a function|undefined is not/.test(s)) {
    vueWarns.push(s)
  }
  origError(...args)
}

// ------------------------------------------------------------ run bundle --
const sleep = ms => new Promise(r => setTimeout(r, ms))

try {
  await import(BUNDLE_URL)
} catch (e) {
  console.error('BUNDLE IMPORT FAILED:', e)
  process.exit(2)
}

if (!registeredExtension) {
  console.error('FAIL: extension was not registered')
  process.exit(1)
}

// run lifecycle: setup mounts the Vue app
try {
  await registeredExtension.setup?.()
} catch (e) {
  errors.push('setup threw: ' + (e.stack || e))
}
await sleep(50)

const root = document.querySelector('#comfyui-model-manager')
const results = []
function check(name, cond, extra = '') {
  results.push({ name, ok: !!cond })
  console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : '  :: ' + extra))
}

check('vue root container created', !!root)
check('vue app rendered something', root && root.innerHTML.length > 0, root ? root.innerHTML.slice(0, 120) : 'no root')

// helper: find a leaf element whose trimmed text matches
const findText = re =>
  Array.from(document.querySelectorAll('*')).find(el => el.children.length === 0 && re.test((el.textContent || '').trim()))
// dispatch a bubbling event once (Vue listeners on ancestor cards receive it)
const fire = (el, type, init = {}) => el && el.dispatchEvent(new window.MouseEvent(type, { bubbles: true, cancelable: true, ...init }))

// ---- open the manager dialog (default = folder Explorer at root) ----
window.dispatchEvent(new window.CustomEvent('open-model-manager'))
await sleep(150)
check('dialog opened (title present)', /Model Manager Neo/.test(document.body.innerHTML))
check('dialog header buttons rendered', document.querySelectorAll('button').length > 3)
check('explorer folder cards rendered', !!findText(/^checkpoints$/))

// ---- context menu fix: navigate into a folder, then right-click a model ----
fire(findText(/^checkpoints$/), 'dblclick')
await sleep(150)
const modelInFolder = findText(/^sd_xl_base$/) || findText(/^dreamshaper$/)
check('navigated into folder (models visible)', !!modelInFolder)
if (modelInFolder) {
  fire(modelInFolder, 'contextmenu', { clientX: 140, clientY: 100 })
  await sleep(120)
  // reka DropdownMenu renders the "Open" item into a body portal; the fix gives
  // it a virtual reference anchored at the cursor (previously it floated away).
  check('context menu rendered Open item', !!findText(/^Open$/))
  // dismiss
  fire(document.body, 'pointerdown')
  await sleep(60)
}

// ---- flat layout (DialogManager) via header toggle: exercises chunk guard ----
const flatBtn = Array.from(document.querySelectorAll('button[title]')).find(b => /Flat View/i.test(b.getAttribute('title') || ''))
check('found flat-layout toggle button', !!flatBtn)
if (flatBtn) {
  fire(flatBtn, 'click')
  await sleep(180)
  check('flat view toolbar rendered', /Search models|All/i.test(document.body.innerHTML))
  check('flat view rendered model cards', /sd_xl_base|dreamshaper/.test(document.body.innerHTML))
}

// ---- model detail dialog (click a card in flat view) ----
const detailTarget = findText(/^sd_xl_base$/) || findText(/^dreamshaper$/)
if (detailTarget) {
  fire(detailTarget, 'click')
  await sleep(150)
  check('model detail dialog opened', /Description|Metadata/i.test(document.body.innerHTML))
} else {
  check('model detail dialog opened', false, 'no model card to click')
}

check('no uncaught runtime errors', errors.length === 0, errors.slice(0, 3).join(' | '))
check('no Vue render/type warnings', vueWarns.length === 0, vueWarns.slice(0, 3).join(' | '))

const failed = results.filter(r => !r.ok)
console.log()
console.log(`RESULT: ${results.length - failed.length} passed, ${failed.length} failed`)
if (errors.length) console.log('ERRORS:\n' + errors.join('\n'))
if (vueWarns.length) console.log('VUE WARNS:\n' + vueWarns.slice(0, 10).join('\n'))
process.exit(failed.length ? 1 : 0)
