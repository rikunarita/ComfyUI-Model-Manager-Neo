"""
Functional smoke tests for the ComfyUI-Model-Manager-Neo Python backend.

Uses a bash-prepared copy of py/ at /home/user/mmneo-tests/mmneo (a real
package with __init__.py). ComfyUI-only modules (folder_paths, server,
comfy.utils) are stubbed, then the real modules are imported and exercised.
"""
import os
import sys
import types
import shutil
import tempfile
import asyncio
import importlib

PKGDIR = "/home/user/mmneo-tests"
sys.path.insert(0, PKGDIR)

TMP = tempfile.mkdtemp(prefix="mmneo-test-")
MODELS = os.path.join(TMP, "models")
CKPT = os.path.join(MODELS, "checkpoints")
LORAS = os.path.join(MODELS, "loras")
os.makedirs(os.path.join(CKPT, "sub.ckpt"), exist_ok=True)  # dir name containing '.ckpt'
os.makedirs(LORAS, exist_ok=True)

# ---------------------------------------------------------------- stubs ----
folder_names_and_paths = {
    "checkpoints": ([CKPT], {".safetensors", ".ckpt", ".gguf"}, None),
    "loras": ([LORAS], {".safetensors"}, None),
    "configs": ([MODELS], set(), None),
    "custom_nodes": ([MODELS], set(), None),
}

folder_paths = types.ModuleType("folder_paths")
folder_paths.folder_names_and_paths = folder_names_and_paths
folder_paths.supported_pt_extensions = {".safetensors", ".ckpt", ".gguf"}
folder_paths.get_folder_paths = lambda name: folder_names_and_paths[name][0]
folder_paths.filter_files_extensions = lambda files, exts: [
    f for f in files if os.path.splitext(f)[1] in set(exts)
]
sys.modules["folder_paths"] = folder_paths

comfy = types.ModuleType("comfy")
comfy_utils = types.ModuleType("comfy.utils")
comfy_utils.safetensors_header = lambda filename, max_size=0: None
comfy.utils = comfy_utils
sys.modules["comfy"] = comfy
sys.modules["comfy.utils"] = comfy_utils

SENT = []


class _Settings:
    def __init__(self):
        self.data = {}

    def get_settings(self, request):
        return dict(self.data)

    def save_settings(self, request, settings):
        self.data = dict(settings)


class _UserManager:
    def __init__(self):
        self.settings = _Settings()


class _Routes:
    def __init__(self):
        self.registered = []

    def _reg(self, method, path):
        def deco(fn):
            self.registered.append((method, path, fn))
            return fn

        return deco

    def get(self, p):
        return self._reg("GET", p)

    def post(self, p):
        return self._reg("POST", p)

    def put(self, p):
        return self._reg("PUT", p)

    def delete(self, p):
        return self._reg("DELETE", p)


class PromptServer:
    def __init__(self):
        self.routes = _Routes()
        self.user_manager = _UserManager()

    async def send_json(self, event, data, sid=None):
        SENT.append((event, data))


PromptServer.instance = PromptServer()
server = types.ModuleType("server")
server.PromptServer = PromptServer
sys.modules["server"] = server

# ------------------------------------------------------------ imports ----
config = importlib.import_module("mmneo.config")
config.extension_uri = TMP
utils = importlib.import_module("mmneo.utils")
utils.config.extension_uri = TMP
auth = importlib.import_module("mmneo.auth")
importlib.import_module("mmneo.thread")
manager = importlib.import_module("mmneo.manager")
download = importlib.import_module("mmneo.download")
information = importlib.import_module("mmneo.information")
upload = importlib.import_module("mmneo.upload")
upload_hf = importlib.import_module("mmneo.upload_hf")

PASSED = []
FAILED = []


def check(name, cond, extra=""):
    (PASSED if cond else FAILED).append(name)
    print(("PASS " if cond else "FAIL ") + name + (("  :: " + str(extra)) if extra and not cond else ""))


class FakeRequest:
    pass


# ------------------------------------------------- utils.is_installed ----
check("is_installed('definitely_missing_xyz>=1') == False", utils.is_installed("definitely_missing_xyz>=1") is False)
check("is_installed('json') == True", utils.is_installed("json") is True)

# ------------------------------------- utils.resolve_file_content_type ----
utils._extension_mimetypes_cache.clear()
check("content type video", utils.resolve_file_content_type("a.mp4") == "video")
check("content type image", utils.resolve_file_content_type("a.png") == "image")

# ---------------------------------------------- utils.get_full_path ------
p = utils.get_full_path("checkpoints", 0, "model.safetensors")
check("get_full_path ok", p.endswith("checkpoints/model.safetensors"), p)
try:
    utils.get_full_path("checkpoints", 0, "../escape.safetensors")
    check("get_full_path traversal blocked", False)
except RuntimeError:
    check("get_full_path traversal blocked", True)

# -------------------------------------------------- manager.scan_models --
open(os.path.join(CKPT, "root_model.safetensors"), "wb").write(b"x")
open(os.path.join(CKPT, "sub.ckpt", "nested.safetensors"), "wb").write(b"x")
open(os.path.join(CKPT, "root_model.preview.png"), "wb").write(b"png")
open(os.path.join(CKPT, "root_model.md"), "w").write("# desc")

mm = manager.ModelManager()
scanned = mm.scan_models("checkpoints", FakeRequest())
by_name = {s["basename"]: s for s in scanned if not s["isFolder"]}
check("scan finds root model", "root_model" in by_name)
check("scan finds nested model", "nested" in by_name)
nested = by_name.get("nested", {})
check(
    "nested preview URL keeps directory name (replace fix)",
    nested.get("preview", "").endswith("/checkpoints/0/sub.ckpt/nested.png"),
    nested.get("preview"),
)
root = by_name.get("root_model", {})
check(
    "root preview URL uses existing preview ext",
    root.get("preview", "").endswith("/checkpoints/0/root_model.png"),
    root.get("preview"),
)
check("scan marks folder entries", any(s["isFolder"] and s["basename"] == "sub.ckpt" for s in scanned))
check("subFolder recorded for nested", nested.get("subFolder") == "sub.ckpt", nested.get("subFolder"))

base_paths = utils.resolve_model_base_paths()
check("configs/custom_nodes excluded", "configs" not in base_paths and "custom_nodes" not in base_paths)

# ------------------------------------------- manager.get_model_info -----
info = mm.get_model_info(os.path.join(CKPT, "root_model.safetensors"))
check("model info description", info["description"] == "# desc")

# ------------------------------------------------ manager.update_model --
mm.update_model(os.path.join(CKPT, "root_model.safetensors"), {"description": "new desc"})
with open(os.path.join(CKPT, "root_model.md"), encoding="utf-8") as f:
    check("update description", f.read() == "new desc")

mm.update_model(
    os.path.join(CKPT, "root_model.safetensors"),
    {"type": "checkpoints", "pathIndex": "0", "fullname": "moved/renamed.safetensors"},
)
moved = os.path.join(CKPT, "moved", "renamed.safetensors")
check("rename moved model", os.path.isfile(moved))
check("rename moved description", os.path.isfile(os.path.join(CKPT, "moved", "renamed.md")))
check(
    "rename moved preview",
    os.path.isfile(os.path.join(CKPT, "moved", "renamed.png"))
    or os.path.isfile(os.path.join(CKPT, "moved", "renamed.preview.png")),
)

mm.update_model(moved, {"previewFile": "undefined"})
leftovers = [
    f
    for f in os.listdir(os.path.join(CKPT, "moved"))
    if f.startswith("renamed") and not f.endswith(".safetensors") and not f.endswith(".md")
]
check("preview sentinel removes previews", leftovers == [], leftovers)

# -------------------------------------------------- download contract ---
md = download.ModelDownload()
md.download_model_task_status.clear()


async def fake_download_model(self, task_id, request):
    return None


download.ModelDownload.download_model = fake_download_model

task_data = {
    "type": "loras",
    "pathIndex": "0",
    "subFolder": "custom/dir",
    "basename": "mymodel",
    "extension": ".safetensors",
    "downloadPlatform": "civitai",
    "downloadUrl": "https://example.invalid/model.safetensors",
    "sizeBytes": "123",
    "description": "---\n---\ndesc",
    "previewFile": "undefined",
}
task_data["fullname"] = task_data["basename"] + task_data["extension"]

loop = asyncio.new_event_loop()
task_id = loop.run_until_complete(md.create_model_download_task(dict(task_data), FakeRequest()))
content = md.get_task_content(task_id)
check("subFolder joined exactly once", content.fullname == "custom/dir/mymodel.safetensors", content.fullname)
target = utils.get_full_path("loras", 0, content.fullname)
check("download target path correct", target.endswith("loras/custom/dir/mymodel.safetensors"), target)
status = md.get_task_status(task_id)
check("task status created", status.taskId == task_id and status.totalSize == 123)

task_data2 = dict(task_data)
task_data2["subFolder"] = ""
task_id2 = loop.run_until_complete(md.create_model_download_task(dict(task_data2), FakeRequest()))
check("empty subFolder keeps plain name", md.get_task_content(task_id2).fullname == "mymodel.safetensors")

open(os.path.join(LORAS, "exists.safetensors"), "wb").write(b"x")
task_data3 = dict(task_data)
task_data3["subFolder"] = ""
task_data3["fullname"] = "exists.safetensors"
try:
    loop.run_until_complete(md.create_model_download_task(dict(task_data3), FakeRequest()))
    check("existing file rejected", False)
except RuntimeError as e:
    check("existing file rejected", "already exists" in str(e))

loop.run_until_complete(md.delete_model_download_task(task_id2))
dl_dir = utils.get_download_path()
check("delete removed task files", not any(f.startswith(task_id2) for f in os.listdir(dl_dir)))

# ---- end-to-end: _download_complete must honour the sub-folder ----
task_id3 = loop.run_until_complete(md.create_model_download_task(dict(task_data), FakeRequest()))
# simulate a finished download blob
tmp_download = utils.join_path(dl_dir, f"{task_id3}.download")
with open(tmp_download, "wb") as f:
    f.write(b"MODELBYTES")
loop.run_until_complete(md._download_complete(task_id3))
final_path = os.path.join(LORAS, "custom", "dir", "mymodel.safetensors")
check("_download_complete saves into sub-folder", os.path.isfile(final_path), final_path)
check(
    "_download_complete wrote description beside model",
    os.path.isfile(os.path.join(LORAS, "custom", "dir", "mymodel.md")),
)
check("_download_complete removed .download blob", not os.path.exists(tmp_download))

# ------------------------------------------- information (HF searcher) --
hf = information.HuggingfaceModelSearcher()
check("tree filter: empty passes all", hf._match_tree_files("")("a/b.safetensors"))
fb = hf._match_tree_files("unet/model.safetensors")
check("tree filter: blob exact", fb("unet/model.safetensors") and not fb("unet/other.safetensors"))
fd = hf._match_tree_files("split_files")
check(
    "tree filter: dir prefix",
    fd("split_files/vae/a.safetensors") and not fd("split_files2/a.safetensors") and not fd("root.safetensors"),
)
sizes = hf._build_file_sizes(
    [
        {"type": "file", "path": "a.safetensors", "size": 5},
        {"type": "directory", "path": "d", "size": 0},
        {"type": "file", "path": "d/b.safetensors", "size": 7},
    ]
)
check("build_file_sizes recursive-flat", sizes == {"a.safetensors": 5, "d/b.safetensors": 7}, sizes)

# ----------------------------------------------- upload validation ------
up = upload.ModelUploader()


def expect_reject(name, folder, fname):
    try:
        up.validate_upload_target(folder, fname)
        check(name, False, "no exception")
    except RuntimeError:
        check(name, True)


def expect_accept(name, folder, fname):
    try:
        up.validate_upload_target(folder, fname)
        check(name, True)
    except RuntimeError as e:
        check(name, False, e)


expect_accept("upload: base folder ok", CKPT, "model.safetensors")
expect_accept("upload: sub folder ok", os.path.join(CKPT, "sub.ckpt"), "m.safetensors")
expect_reject("upload: arbitrary path rejected", "/tmp", "evil.safetensors")
expect_reject("upload: traversal filename rejected", CKPT, "../../evil.safetensors")
expect_reject("upload: traversal via folder rejected", os.path.join(CKPT, "..", ".."), "evil.safetensors")
expect_reject("upload: missing folder rejected", None, "m.safetensors")
expect_reject("upload: absolute filename rejected", CKPT, "/etc/passwd")

task_id_l, status_l = up.create_local_task(os.path.join(CKPT, "sub.ckpt"), "nested.safetensors")
check(
    "create_local_task resolves",
    status_l is not None and status_l.type == "checkpoints" and status_l.fullname == "sub.ckpt/nested.safetensors",
    status_l,
)

# ---------------------------------------------------- auth roundtrip ----
auth._api_key_instance = None
ak = auth.get_api_key()
ak._cache_file = os.path.join(TMP, "private.key")
ak.set_value("civitai", "SECRET-VALUE-123456")
store = utils.load_dict_pickle_file(ak._cache_file)
check("api key persisted", store.get("civitai") == "SECRET-VALUE-123456")

# ---------------------------------------------------- routes registered --
routes = PromptServer.instance.routes
expected_paths = [
    ("GET", "/model-manager/models"),
    ("GET", "/model-manager/models/{folder}"),
    ("PUT", "/model-manager/model/{type}/{index}/{filename:.*}"),
    ("DELETE", "/model-manager/model/{type}/{index}/{filename:.*}"),
    ("POST", "/model-manager/model"),
    ("POST", "/model-manager/download/init"),
    ("POST", "/model-manager/download/setting"),
    ("GET", "/model-manager/download/task"),
    ("PUT", "/model-manager/download/{task_id}"),
    ("DELETE", "/model-manager/download/{task_id}"),
    ("GET", "/model-manager/model-info"),
    ("GET", "/model-manager/model-info/scan"),
    ("POST", "/model-manager/model-info/scan"),
    ("GET", "/model-manager/preview/{type}/{index}/{filename:.*}"),
    ("GET", "/model-manager/preview/download/{filename}"),
    ("GET", "/model-manager/supported-extensions"),
    ("POST", "/model-manager/upload"),
    ("GET", "/model-manager/hf/whoami"),
    ("POST", "/model-manager/hf/upload"),
]
manager.ModelManager().add_routes(routes)
download.get_model_download().add_routes(routes)
information.Information().add_routes(routes)
upload.ModelUploader().add_routes(routes)
upload_hf.HfUploader().add_routes(routes)
have = {(m, p) for m, p, _ in routes.registered}
missing = [e for e in expected_paths if e not in have]
check("all API routes registered", not missing, missing)

SENT.clear()
loop.run_until_complete(utils.send_json("test_event", {"a": 1}))
check("send_json dispatches", bool(SENT) and SENT[0][0] == "test_event")

loop.close()
shutil.rmtree(TMP, ignore_errors=True)

print()
print(f"RESULT: {len(PASSED)} passed, {len(FAILED)} failed")
if FAILED:
    print("FAILED:", FAILED)
    sys.exit(1)
print("ALL PYTHON BACKEND TESTS PASSED")
