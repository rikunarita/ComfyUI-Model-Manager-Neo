import asyncio
import functools
import os
import re
import math
import yaml
import requests
import markdownify

import folder_paths

from aiohttp import web
from abc import ABC, abstractmethod
from urllib.parse import urlparse, parse_qs
from PIL import Image
from io import BytesIO

from . import utils
from . import config
from . import thread
from . import auth


class ModelSearcher(ABC):
    """
    Abstract class for model searcher.
    """

    @abstractmethod
    def search_by_url(self, url: str) -> list[dict]:
        pass

    @abstractmethod
    def search_by_hash(self, hash: str) -> dict:
        pass


class UnknownWebsiteSearcher(ModelSearcher):
    def search_by_url(self, url: str):
        raise RuntimeError("Unknown Website, please input a URL from huggingface.co or civitai.com.")

    def search_by_hash(self, hash: str):
        raise RuntimeError("Unknown Website, unable to search with hash value.")


class CivitaiModelSearcher(ModelSearcher):
    def search_by_url(self, url: str):
        parsed_url = urlparse(url)

        pathname = parsed_url.path
        match = re.match(r"^/models/(\d*)", pathname)
        model_id = match.group(1) if match else None

        query_params = parse_qs(parsed_url.query)
        version_id = query_params.get("modelVersionId", [None])[0]

        if not model_id:
            return []

        headers = auth.get_civitai_headers()
        response = requests.get(f"https://civitai.com/api/v1/models/{model_id}", headers=headers)
        response.raise_for_status()
        res_data: dict = response.json()

        model_versions: list[dict] = res_data["modelVersions"]
        if version_id:
            model_versions = utils.filter_with(model_versions, {"id": int(version_id)})

        models: list[dict] = []

        for version in model_versions:
            version_files: list[dict] = version.get("files", [])
            model_files = utils.filter_with(version_files, {"type": "Model"})
            # issue: https://github.com/hayden-cn/ComfyUI-Model-Manager/issues/188
            # Some Embeddings do not have Model file, but Negative
            # Make sure there are at least downloadable files
            model_files = version_files if len(model_files) == 0 else model_files

            shortname = version.get("name", None) if len(model_files) > 0 else None

            for file in model_files:
                name = file.get("name", None)
                extension = os.path.splitext(name)[1]
                basename = os.path.splitext(name)[0]

                metadata_info = {
                    "website": "Civitai",
                    "modelPage": f"https://civitai.com/models/{model_id}?modelVersionId={version.get('id')}",
                    "author": res_data.get("creator", {}).get("username", None),
                    "baseModel": version.get("baseModel"),
                    "hashes": file.get("hashes"),
                    "metadata": file.get("metadata"),
                    "preview": [i["url"] for i in version["images"]],
                }

                description_parts: list[str] = []
                description_parts.append("---")
                description_parts.append(yaml.dump(metadata_info).strip())
                description_parts.append("---")
                description_parts.append("")
                description_parts.append("# Trigger Words")
                description_parts.append("")
                description_parts.append(", ".join(version.get("trainedWords", ["No trigger words"])))
                description_parts.append("")
                description_parts.append("# About this version")
                description_parts.append("")
                description_parts.append(markdownify.markdownify(version.get("description", "<p>No description about this version</p>")).strip())
                description_parts.append("")
                description_parts.append(f"# {res_data.get('name')}")
                description_parts.append("")
                description_parts.append(markdownify.markdownify(res_data.get("description", "<p>No description about this model</p>")).strip())
                description_parts.append("")

                model = {
                    "id": version.get("id"),
                    "shortname": shortname or basename,
                    "basename": basename,
                    "extension": extension,
                    "preview": metadata_info.get("preview"),
                    "sizeBytes": file.get("sizeKB", 0) * 1024,
                    "type": self._resolve_model_type(res_data.get("type", "")),
                    "pathIndex": 0,
                    "subFolder": "",
                    "description": "\n".join(description_parts),
                    "metadata": file.get("metadata"),
                    "downloadPlatform": "civitai",
                    "downloadUrl": file.get("downloadUrl"),
                    "hashes": file.get("hashes"),
                    "files": version_files if len(version_files) > 1 else None,
                }
                models.append(model)

        return models

    # BUG FIX: `_resolve_model_type` was dropped in the fork and the Civitai
    # model type hardcoded to "". The Create Download Task dialog then had no
    # type to pre-select, so every Civitai download had to be typed by hand
    # (and was rejected with "Please select model type first" otherwise).
    # Restored from upstream, with one hardening step: the resolved type is
    # only used when ComfyUI actually has a matching model folder, so Civitai
    # categories with no local counterpart ("Wildcards", "Poses", ...) degrade
    # to "" exactly as before instead of producing an unusable type.
    CIVITAI_TYPE_MAP = {
        "TextualInversion": "embeddings",
        "LoCon": "loras",
        "DoRA": "loras",
        "Controlnet": "controlnet",
        "Upscaler": "upscale_models",
        "VAE": "vae",
        "unknown": "",
    }

    def _resolve_model_type(self, model_type: str) -> str:
        if not model_type:
            return ""
        resolved = self.CIVITAI_TYPE_MAP.get(model_type, f"{model_type.lower()}s")
        if not resolved:
            return ""
        return resolved if resolved in utils.resolve_model_base_paths() else ""

    def search_by_hash(self, hash: str):
        if not hash:
            raise RuntimeError("Hash value is empty.")

        headers = auth.get_civitai_headers()
        response = requests.get(f"https://civitai.com/api/v1/model-versions/by-hash/{hash}", headers=headers)
        response.raise_for_status()
        version: dict = response.json()

        model_id = version.get("modelId")
        version_id = version.get("id")

        model_page = f"https://civitai.com/models/{model_id}?modelVersionId={version_id}"

        models = self.search_by_url(model_page)

        for model in models:
            sha256 = model.get("hashes", {}).get("SHA256")
            if sha256 == hash:
                return model

        return models[0]

class HuggingfaceModelSearcher(ModelSearcher):
    def search_by_url(self, url: str):
        parsed_url = urlparse(url)

        pathname = parsed_url.path
        path_parts = [p for p in pathname.strip("/").split("/") if p]

        if len(path_parts) < 2:
            raise RuntimeError(f"Invalid HuggingFace URL: {url}")

        space = path_parts[0]
        name = path_parts[1]
        model_id = f"{space}/{name}"

        # Extract revision and rest_pathname from tree/blob paths
        revision = "main"
        rest_pathname = ""
        if len(path_parts) >= 4 and path_parts[2] in ("tree", "blob"):
            revision = path_parts[3]
            rest_pathname = "/".join(path_parts[4:])

        headers = auth.get_hf_headers()

        # Fetch model info from HF API
        response = requests.get(f"https://huggingface.co/api/models/{model_id}", headers=headers)
        response.raise_for_status()
        res_data: dict = response.json()

        # Fetch file tree to get actual file sizes
        file_sizes = {}
        try:
            # BUG FIX: without `recursive=true` the tree API only returns the
            # repository root, so files inside sub-directories never got a
            # size (shown as 0 B until the download corrected it).
            tree_url = f"https://huggingface.co/api/models/{model_id}/tree/{revision}?recursive=true"
            tree_response = requests.get(tree_url, headers=headers)
            if tree_response.status_code == 200:
                tree_data = tree_response.json()
                file_sizes = self._build_file_sizes(tree_data)
        except Exception as e:
            utils.print_warning(f"Failed to fetch file tree for size info: {e}")

        sibling_files: list[str] = [x.get("rfilename") for x in res_data.get("siblings", [])]

        model_files = utils.filter_with(
            utils.filter_with(sibling_files, self._match_model_files()),
            self._match_tree_files(rest_pathname),
        )

        image_files = utils.filter_with(
            utils.filter_with(sibling_files, self._match_image_files()),
            self._match_tree_files(rest_pathname),
        )
        image_files = [f"https://huggingface.co/{model_id}/resolve/{revision}/{filename}" for filename in image_files]

        models: list[dict] = []

        for filename in model_files:
            fullname = os.path.basename(filename)
            extension = os.path.splitext(fullname)[1]
            basename = os.path.splitext(fullname)[0]
            size_bytes = file_sizes.get(filename, 0)

            metadata_info = {
                "website": "HuggingFace",
                "modelPage": f"https://huggingface.co/{model_id}",
                "author": res_data.get("author", None),
                "preview": image_files,
            }

            description_parts: list[str] = []
            description_parts.append("---")
            description_parts.append(yaml.dump(metadata_info).strip())
            description_parts.append("---")
            description_parts.append("")
            description_parts.append("# Trigger Words")
            description_parts.append("")
            description_parts.append("No trigger words")
            description_parts.append("")
            description_parts.append("# About this version")
            description_parts.append("")
            description_parts.append("No description about this version")
            description_parts.append("")
            description_parts.append(f"# {res_data.get('name')}")
            description_parts.append("")
            description_parts.append("No description about this model")
            description_parts.append("")

            model = {
                "id": filename,
                "shortname": filename,
                "basename": basename,
                "extension": extension,
                "preview": image_files,
                "sizeBytes": size_bytes,
                "type": "",
                "pathIndex": 0,
                "subFolder": "",
                "description": "\n".join(description_parts),
                "metadata": {},
                "downloadPlatform": "huggingface",
                "downloadUrl": f"https://huggingface.co/{model_id}/resolve/{revision}/{filename}?download=true",
                "revision": revision,
            }
            models.append(model)

        return models

    def search_by_hash(self, hash: str):
        raise RuntimeError("Hash search is not supported by Huggingface.")

    def _build_file_sizes(self, tree_data):
        """Recursively build a dict of {filepath: size} from HF tree API response."""
        sizes = {}
        if isinstance(tree_data, list):
            for item in tree_data:
                if item.get("type") == "file":
                    sizes[item.get("path", "")] = item.get("size", 0)
                elif item.get("type") == "directory":
                    children = item.get("children", [])
                    if children:
                        sizes.update(self._build_file_sizes(children))
        return sizes

    def _match_model_files(self):
        extension = [
            ".bin",
            ".ckpt",
            ".gguf",
            ".onnx",
            ".pt",
            ".pth",
            ".safetensors",
        ]

        def _filter_model_files(file: str):
            return any(file.endswith(ext) for ext in extension)

        return _filter_model_files

    def _match_image_files(self):
        extension = [
            ".png",
            ".webp",
            ".jpeg",
            ".jpg",
            ".jfif",
            ".gif",
            ".apng",
        ]

        def _filter_image_files(file: str):
            return any(file.endswith(ext) for ext in extension)

        return _filter_image_files

    def _match_tree_files(self, pathname: str):
        # BUG FIX: `rest_pathname` (built in search_by_url) already has the
        # leading `tree|blob/<revision>` segments stripped, so the previous
        # check that required the first segment to be "tree"/"blob" never
        # matched and the filter degenerated into a no-op returning every
        # model file of the repository. The remaining pathname IS the
        # sub-path: match the exact file (blob URL) or everything inside the
        # directory (tree URL).
        prefix = pathname.strip("/")

        def _filter_tree_files(file: str):
            if not prefix:
                return True
            return file == prefix or file.startswith(prefix + "/")

        return _filter_tree_files


class Information:
    def add_routes(self, routes):

        @routes.get("/model-manager/model-info")
        async def fetch_model_info(request):
            """
            Fetch model information from network with model page.
            """
            try:
                model_page = request.query.get("model-page", None)
                # BUG FIX: `search_by_url` performs one or more blocking
                # `requests.get` round trips (Civitai model + version data, or
                # the Hugging Face model info AND recursive file tree). Running
                # them inline froze ComfyUI's event loop for the whole lookup -
                # no websocket traffic, no other request served - which is the
                # same defect already fixed for hashing, the Civitai hash
                # lookup, the preview download and the model-library walks.
                loop = asyncio.get_running_loop()
                result = await loop.run_in_executor(None, self.fetch_model_info, model_page)
                return web.json_response({"success": True, "data": result})
            except Exception as e:
                error_msg = f"Fetch model info failed: {str(e)}"
                utils.print_error(error_msg)
                return web.json_response({"success": False, "error": error_msg})

        @routes.get("/model-manager/model-info/scan")
        async def get_model_info_download_task(request):
            """
            Get model information download task list.
            """
            try:
                result = self.get_scan_model_info_task_list()
                if result is not None:
                    await self.download_model_info(request)
                return web.json_response({"success": True, "data": result})
            except Exception as e:
                error_msg = f"Get model info download task list failed: {str(e)}"
                utils.print_error(error_msg)
                return web.json_response({"success": False, "error": error_msg})

        @routes.post("/model-manager/model-info/scan")
        async def create_model_info_download_task(request):
            """
            Create a task to download model information.

            - scanMode: The alternatives are diff and full.
            - mode: The alternatives are diff and full.
            - path: Scanning root path.
            """
            post = await utils.get_request_body(request)
            try:
                # TODO scanMode is deprecated, use mode instead.
                scan_mode = post.get("scanMode", "diff")
                scan_mode = post.get("mode", scan_mode)
                scan_path = post.get("path", None)
                result = await self.create_scan_model_info_task(scan_mode, scan_path, request)
                return web.json_response({"success": True, "data": result})
            except Exception as e:
                error_msg = f"Download model info failed: {str(e)}"
                utils.print_error(error_msg)
                return web.json_response({"success": False, "error": error_msg})

        @routes.get("/model-manager/preview/{type}/{index}/{filename:.*}")
        async def read_model_preview(request):
            """
            Get the file stream of the specified preview
            If the file does not exist, no-preview.png is returned.

            :param type: The type of the model. eg.checkpoints, loras, vae, etc.
            :param index: The index of the model folders.
            :param filename: The filename of the preview.
            """
            model_type = request.match_info.get("type", None)
            index = int(request.match_info.get("index", None))
            filename = request.match_info.get("filename", None)

            extension_uri = config.extension_uri

            try:
                folders = folder_paths.get_folder_paths(model_type)
                base_path = folders[index]
                abs_path = utils.join_path(base_path, filename)
                preview_name = utils.get_model_preview_name(abs_path)
                if preview_name:
                    dir_name = os.path.dirname(abs_path)
                    abs_path = utils.join_path(dir_name, preview_name)
            except:
                abs_path = extension_uri

            if not os.path.isfile(abs_path):
                abs_path = utils.join_path(extension_uri, "assets", "no-preview.png")

            # Determine content type from the actual file
            content_type = utils.resolve_file_content_type(abs_path)

            if content_type == "video":
                # Serve video files directly
                return web.FileResponse(abs_path)
            else:
                # Serve image files (WebP or fallback images)
                image_data = self.get_image_preview_data(abs_path)
                return web.Response(body=image_data.getvalue(), content_type="image/webp")

        @routes.get("/model-manager/preview/download/{filename}")
        async def read_download_preview(request):
            filename = request.match_info.get("filename", None)
            extension_uri = config.extension_uri

            download_path = utils.get_download_path()
            preview_path = utils.join_path(download_path, filename)

            if not os.path.isfile(preview_path):
                preview_path = utils.join_path(extension_uri, "assets", "no-preview.png")

            return web.FileResponse(preview_path)

    def get_image_preview_data(self, filename: str):
        with Image.open(filename) as img:
            max_size = 1024

            exif_data = img.info.get("exif")
            icc_profile = img.info.get("icc_profile")

            if getattr(img, "is_animated", False) and img.n_frames > 1:
                total_frames = img.n_frames
                step = max(1, math.ceil(total_frames / 30))

                frames, durations = [], []

                for frame_idx in range(0, total_frames, step):
                    img.seek(frame_idx)
                    frame = img.copy()
                    frame.thumbnail((max_size, max_size), Image.Resampling.NEAREST)

                    frames.append(frame)
                    durations.append(img.info.get("duration", 100) * step)

                save_args = {
                    "format": "WEBP",
                    "save_all": True,
                    "append_images": frames[1:],
                    "duration": durations,
                    "loop": 0,
                    "quality": 80,
                    "method": 0,
                    "allow_mixed": False,
                }

                if exif_data:
                    save_args["exif"] = exif_data

                if icc_profile:
                    save_args["icc_profile"] = icc_profile

                img_byte_arr = BytesIO()
                frames[0].save(img_byte_arr, **save_args)
                img_byte_arr.seek(0)
                return img_byte_arr

            img.thumbnail((max_size, max_size), Image.Resampling.BICUBIC)

            img_byte_arr = BytesIO()
            save_args = {"format": "WEBP", "quality": 80}

            if exif_data:
                save_args["exif"] = exif_data
            if icc_profile:
                save_args["icc_profile"] = icc_profile

            img.save(img_byte_arr, **save_args)
            img_byte_arr.seek(0)
            return img_byte_arr

    def fetch_model_info(self, model_page: str):
        if not model_page:
            return []

        model_searcher = self.get_model_searcher_by_url(model_page)
        result = model_searcher.search_by_url(model_page)
        return result

    def get_scan_information_task_filepath(self):
        download_dir = utils.get_download_path()
        return utils.join_path(download_dir, "scan_information.task")

    def get_scan_model_info_task_list(self):
        scan_info_task_file = self.get_scan_information_task_filepath()
        if os.path.isfile(scan_info_task_file):
            return utils.load_dict_pickle_file(scan_info_task_file)
        return None

    async def create_scan_model_info_task(self, scan_mode: str, scan_path: str | None, request):
        scan_info_task_file = self.get_scan_information_task_filepath()
        scan_info_task_content = {"mode": scan_mode}
        scan_models: dict[str, bool] = {}

        scan_paths: list[str] = []
        if scan_path is None:
            model_base_paths = utils.resolve_model_base_paths()
            # BUG FIX: ComfyUI registers the SAME directory under several model
            # types (e.g. text_encoders -> [text_encoders, clip],
            # diffusion_models -> [unet, diffusion_models]) and custom nodes add
            # further aliases via add_model_folder_path(). The naive loop
            # therefore walked identical trees once per alias. `scan_models` is
            # keyed by absolute path, so visiting a tree twice can only re-set
            # keys that already exist - de-duplicating produces a byte-identical
            # result (same keys, same values, same insertion order) while
            # removing whole redundant `os.walk` passes. That matters because
            # this walk runs inside the POST handler: it is what pushed the
            # request past ComfyUI's 60s api.fetchApi response timeout on large
            # libraries (see DialogScanning.vue).
            seen_paths: set[str] = set()
            for model_type in model_base_paths:
                folders, *others = folder_paths.folder_names_and_paths[model_type]
                for base_path in folders:
                    normalized = utils.normalize_path(base_path)
                    if normalized in seen_paths:
                        utils.print_debug(f"Skipping duplicate scan path: {base_path}")
                        continue
                    seen_paths.add(normalized)
                    scan_paths.append(base_path)
        else:
            scan_paths = [scan_path]

        # BUG FIX: walking every model folder is a blocking `os.walk` over the
        # whole library. Running it directly in the request handler froze the
        # server event loop for its entire duration — no websocket traffic (so
        # no progress reached the browser) and no other request could be served,
        # which made the UI look dead while "Batch scan" was starting. Same
        # treatment the hashing/Civitai lookups already got: run it off-loop.
        loop = asyncio.get_running_loop()
        include_hidden_files = utils.get_setting_value(request, "scan.include_hidden_files", False)

        for base_path in scan_paths:
            files = await loop.run_in_executor(
                None, utils.recursive_search_files, base_path, include_hidden_files
            )
            models = folder_paths.filter_files_extensions(files, folder_paths.supported_pt_extensions)
            for fullname in models:
                fullname = utils.normalize_path(fullname)
                abs_model_path = utils.join_path(base_path, fullname)
                utils.print_debug(f"Found model: {abs_model_path}")
                scan_models[abs_model_path] = False

        scan_info_task_content["models"] = scan_models
        utils.save_dict_pickle_file(scan_info_task_file, scan_info_task_content)
        await self.download_model_info(request)
        return scan_info_task_content

    download_thread_pool = thread.DownloadThreadPool()

    # Fixed id so a running scan can be detected: previously every dialog
    # (re-)open that hit GET /model-info/scan submitted ANOTHER concurrent
    # scanner for the same task file (uuid ids could never collide).
    SCAN_TASK_ID = "model_info_scan"

    async def download_model_info(self, request):
        async def download_information_task(task_id: str):
            loop = asyncio.get_running_loop()
            scan_info_task_file = self.get_scan_information_task_filepath()
            scan_info_task_content = utils.load_dict_pickle_file(scan_info_task_file)
            scan_mode = scan_info_task_content.get("mode", "diff")
            scan_models: dict[str, bool] = scan_info_task_content.get("models", {})
            failed_count = 0
            for key, value in scan_models.items():
                if value is True:
                    continue

                abs_model_path = key

                try:
                    # BUG FIX: this prologue used to sit OUTSIDE the try, so an
                    # error while merely *inspecting* one model - its folder was
                    # deleted or moved mid-scan, or os.listdir() inside
                    # get_model_description_name hit a permission error -
                    # escaped the loop AND the whole task. The completion event
                    # was never sent and the task file never removed, so the
                    # dialog froze with no way to finish. Every per-model step is
                    # guarded now; one bad model can only ever cost that model.
                    base_path = os.path.dirname(abs_model_path)

                    image_name = utils.get_model_preview_name(abs_model_path)
                    abs_image_path = utils.join_path(base_path, image_name)

                    has_preview = os.path.isfile(abs_image_path)

                    description_name = utils.get_model_description_name(abs_model_path)
                    abs_description_path = utils.join_path(base_path, description_name) if description_name else None
                    has_description = os.path.isfile(abs_description_path) if abs_description_path else False

                    utils.print_info(f"Checking model {abs_model_path}")
                    utils.print_debug(f"Scan mode: {scan_mode}")
                    utils.print_debug(f"Has preview: {has_preview}")
                    utils.print_debug(f"Has description: {has_description}")

                    if scan_mode == "full" or not has_preview or not has_description:
                        utils.print_debug(f"Calculate sha256 for {abs_model_path}")
                        # BUG FIX: sha256 of multi-GB files, the Civitai lookup
                        # and the preview download are blocking calls. Running
                        # them directly froze the whole server event loop for
                        # the duration (no websocket traffic, no other request
                        # could be served). Offload them to the executor.
                        hash_value = await loop.run_in_executor(None, utils.calculate_sha256, abs_model_path)
                        utils.print_info(f"Searching model info by hash {hash_value}")
                        searcher = CivitaiModelSearcher()
                        model_info = await loop.run_in_executor(None, searcher.search_by_hash, hash_value)

                        preview_url_list = model_info.get("preview", [])
                        preview_url = preview_url_list[0] if preview_url_list else None
                        if preview_url:
                            utils.print_debug(f"Save preview to {abs_model_path}")
                            preview_headers = None
                            if model_info.get("downloadPlatform") == "civitai":
                                preview_headers = auth.get_civitai_headers()
                            elif model_info.get("downloadPlatform") == "huggingface":
                                preview_headers = auth.get_hf_headers()
                            await loop.run_in_executor(
                                None,
                                functools.partial(
                                    utils.save_model_preview,
                                    abs_model_path,
                                    preview_url,
                                    headers=preview_headers,
                                ),
                            )

                        description = model_info.get("description", None)
                        if description:
                            utils.save_model_description(abs_model_path, description)

                    scan_models[abs_model_path] = True
                    scan_info_task_content["models"] = scan_models
                    utils.save_dict_pickle_file(scan_info_task_file, scan_info_task_content)
                    utils.print_debug("Send update scan information task to frontend.")
                    await utils.send_json("update_scan_information_task", scan_info_task_content)
                except Exception as e:
                    utils.print_error(f"Failed to download model info for {abs_model_path}: {e}")
                    # Only count it as a failure when the scan work itself broke;
                    # if `scan_models` is already True the exception came from
                    # the reporting step below and the model did get scanned.
                    if scan_models.get(abs_model_path) is not True:
                        failed_count += 1

                    # BUG FIX - this is why the counter stalled at "11 / 12".
                    # A model that is not indexed on Civitai makes
                    # `search_by_hash` raise a 404, and the handler above only
                    # logged it: the model was never marked as processed, so
                    # `scanCompleteCount` could never reach `scanTotalCount`.
                    # The dialog sat on N-1 / N forever - the progress bar never
                    # hit 100% and the "complete" state was never shown - even
                    # though `complete_scan_information_task` had already been
                    # delivered (its model-list refresh spinner was the only
                    # visible sign that the scan had ended).
                    #
                    # The counter measures how many models have been *attempted*,
                    # not how many lookups succeeded, so a failed model counts as
                    # processed. The failure is not hidden: it is logged above,
                    # tallied into `failed_count`, and reported to the UI in the
                    # completion event.
                    scan_models[abs_model_path] = True
                    try:
                        scan_info_task_content["models"] = scan_models
                        utils.save_dict_pickle_file(scan_info_task_file, scan_info_task_content)
                        utils.print_debug("Send update scan information task to frontend.")
                        await utils.send_json("update_scan_information_task", scan_info_task_content)
                    except Exception as report_error:
                        # Never let a reporting problem abort the remaining scan.
                        utils.print_error(f"Failed to report scan progress for {abs_model_path}: {report_error}")

            if os.path.exists(scan_info_task_file):
                os.remove(scan_info_task_file)
            if failed_count:
                utils.print_warning(
                    f"{failed_count} model(s) failed to scan and were counted as processed "
                    f"so the progress could complete. See the errors above for details."
                )
            utils.print_info("Completed scan model information.")
            # Explicit completion signal carrying the final state, so the
            # frontend can react (toast + refresh model previews) even if an
            # earlier per-model update was missed. `failed` is additive: the
            # frontend still reads `models` exactly as before.
            await utils.send_json("complete_scan_information_task", {"models": scan_models, "failed": failed_count})

        try:
            # Never stack concurrent scans on the same task file.
            if self.SCAN_TASK_ID in self.download_thread_pool.running_tasks:
                utils.print_debug("Scan model information task already running, skipping submit.")
                return
            self.download_thread_pool.submit(download_information_task(self.SCAN_TASK_ID), self.SCAN_TASK_ID)
        except Exception as e:
            utils.print_debug(str(e))

    def get_model_searcher_by_url(self, url: str) -> ModelSearcher:
        parsed_url = urlparse(url)
        host_name = parsed_url.hostname
        if host_name == "civitai.com":
            return CivitaiModelSearcher()
        elif host_name == "huggingface.co":
            return HuggingfaceModelSearcher()
        return UnknownWebsiteSearcher()
